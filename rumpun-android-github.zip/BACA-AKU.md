# Rumpun — bangun APK lewat GitHub, tanpa Android Studio

PWABuilder sedang rusak di sisi peladen mereka (bug resmi #6406, dilaporkan
1 Oktober 2026). Folder ini melewati mereka sepenuhnya.

Isinya proyek Android sungguhan. GitHub yang akan membangunnya di komputer
mereka, gratis, lalu memberimu berkas `.apk` untuk diunduh. Waktu yang kamu
butuhkan sekitar 15 menit, dan sekitar 5 menit di antaranya hanya menunggu.

**Kerjakan ini di laptop.** Mengunggah banyak berkas lewat peramban HP sangat
merepotkan dan mudah putus di tengah jalan.

---

## Langkah 1 — Buat akun dan repositori

1. Buka **github.com**, daftar kalau belum punya akun (gratis)
2. Tekan tombol **+** di kanan atas → **New repository**
3. Isi **Repository name**: `rumpun-apk`
4. Pilih **Public**
5. Jangan centang apa pun di bagian "Initialize this repository"
6. Tekan **Create repository**

## Langkah 2 — Unggah berkas proyek

Di halaman repositori yang baru dibuat, cari tautan
**"uploading an existing file"**.

1. Ekstrak zip ini di laptopmu
2. Buka foldernya, **pilih semua isinya** (Ctrl+A) — folder `app`, folder
   `.github`, `build.gradle`, `settings.gradle`, `gradle.properties`
3. Seret semuanya ke kotak unggah di halaman GitHub
4. Tunggu sampai daftarnya penuh, lalu tekan **Commit changes**

> **Penting:** folder `.github` sering disembunyikan oleh Windows dan macOS
> karena namanya diawali titik. Kalau tidak kelihatan, aktifkan tampilan
> berkas tersembunyi dulu. Tanpa folder itu, GitHub tidak tahu harus
> membangun apa pun.

## Langkah 3 — Tunggu GitHub membangunnya

1. Buka tab **Actions** di repositorimu
2. Akan ada satu proses berjalan bernama **Bangun APK Rumpun** dengan
   lingkaran kuning berputar
3. Tunggu sampai berubah jadi centang hijau. Build pertama biasanya
   **4–7 menit** karena GitHub mengunduh Android SDK dulu

Kalau yang muncul silang merah, tekan prosesnya, buka langkah yang gagal,
salin pesan galatnya, dan kirim ke saya.

## Langkah 4 — Unduh APK-mu

1. Tekan proses yang sudah hijau
2. Gulir ke bawah sampai bagian **Artifacts**
3. Unduh **Rumpun-APK** — berupa zip
4. Di dalamnya ada:

| Berkas | Keterangan |
|---|---|
| `Rumpun.apk` | **Ini yang kamu pasang dan kumpulkan** |
| `Rumpun-uji-coba.apk` | Cadangan, kalau yang pertama bermasalah |
| `rumpun.keystore` | Kunci penandatangan dari build ini |

## Langkah 5 — Pasang di HP

Kirim `Rumpun.apk` ke HP Android (WhatsApp ke diri sendiri, Google Drive,
atau kabel USB). Buka berkasnya. Android akan bertanya apakah kamu
mengizinkan pemasangan dari sumber ini — izinkan, lalu pasang.

---

## Yang perlu kamu tahu tentang aplikasi ini

**Seluruh isinya ada di dalam APK.** Katalog, halaman produk, keranjang,
checkout, riwayat pesanan, dan diagram alur omnichannel semuanya tersimpan
di dalam berkas aplikasi, bukan diambil dari internet. Artinya:

- Jalan tanpa sinyal, di mana pun kamu presentasi
- Tidak ada bilah alamat peramban di bagian atas
- Tidak bergantung pada Netlify. Kalau situsnya mati, aplikasinya tetap hidup
- Tidak perlu `assetlinks.json` atau urusan verifikasi domain

**Mode gelap ikut mode HP.** Aplikasi membaca pengaturan perangkat dan
menyesuaikan temanya sendiri.

**Tombol kembali bawaan Android berfungsi** untuk berpindah antar layar,
bukan langsung menutup aplikasi.

**Tautan ke luar** (WhatsApp, Instagram, situs Canva) terbuka di aplikasi
yang sesuai — asalkan sudah kamu isi, lihat di bawah.

---

## Mengubah isinya

Semua tampilan dan data ada di satu berkas:
`app/src/main/assets/index.html`

Untuk mengisi tautan kanalmu, cari baris ini di dekat awal blok `<script>`:

```js
var LINK={situs:"",wa:"",ig:""};
```

Isi menjadi:

```js
var LINK={
  situs:"https://growbin.my.canva.site",
  wa:"https://wa.me/62812xxxxxxx?text=Halo%20GrowBin",
  ig:"https://instagram.com/akunmu"
};
```

Nomor WhatsApp memakai **62**, buang angka 0 di depan.

Setelah mengubahnya, unggah ulang berkas itu ke GitHub (buka berkasnya di
GitHub → ikon pensil → tempel → Commit). GitHub otomatis membangun ulang,
dan APK baru muncul di tab Actions beberapa menit kemudian.

**Kalau memasang versi baru:** hapus dulu aplikasi lama di HP. Setiap build
membuat kunci penandatangan baru, jadi Android menganggapnya aplikasi yang
berbeda dan menolak menimpa.

---

## Catatan jujur untuk laporanmu

Aplikasi ini adalah **pembungkus WebView**: sebuah aplikasi Android sungguhan
yang di dalamnya menampilkan antarmuka web. Ini cara yang sah dan umum
dipakai di industri, tetapi kalau dosenmu bertanya, jawab apa adanya —
jangan mengaku membangunnya dengan Kotlin dari nol. Kode Java-nya ada di
`app/src/main/java/id/rumpun/simulasi/MainActivity.java`, sekitar 170 baris,
dan kamu bisa membukanya kalau diminta menunjukkan.

Rumpun adalah simulasi akademik untuk tugas mata kuliah Simulasi Digital
Marketing, Program Studi Manajemen S1, Universitas Pamulang. Bukan toko
sungguhan, tidak menerima pembayaran, dan tidak berafiliasi dengan
marketplace mana pun. Nama toko, rating, jumlah terjual, dan ulasan di
dalamnya adalah data contoh.
