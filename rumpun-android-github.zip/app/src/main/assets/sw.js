/* Rumpun - service worker sederhana.
   Naikkan angka VERSI setiap kali kamu mengubah index.html,
   supaya pengguna lama mendapat versi baru, bukan versi tersimpan. */
var VERSI = "rumpun-v2";
var INTI = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-512-maskable.png",
  "/icons/apple-touch-icon.png"
];

self.addEventListener("install", function(e){
  e.waitUntil(caches.open(VERSI).then(function(c){ return c.addAll(INTI); }).then(function(){
    return self.skipWaiting();
  }));
});

self.addEventListener("activate", function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.map(function(k){ return k===VERSI ? null : caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});

self.addEventListener("fetch", function(e){
  var req = e.request;
  if(req.method !== "GET") return;

  /* Halaman: coba jaringan dulu supaya pembaruan cepat terlihat,
     jatuh ke salinan tersimpan kalau sedang tidak ada sinyal. */
  if(req.mode === "navigate"){
    e.respondWith(
      fetch(req).then(function(res){
        var salin = res.clone();
        caches.open(VERSI).then(function(c){ c.put("/index.html", salin); });
        return res;
      }).catch(function(){
        return caches.match("/index.html").then(function(r){ return r || caches.match("/"); });
      })
    );
    return;
  }

  /* Sisanya: pakai salinan tersimpan dulu, ambil dari jaringan kalau belum ada. */
  e.respondWith(
    caches.match(req).then(function(hit){
      if(hit) return hit;
      return fetch(req).then(function(res){
        if(res && res.status === 200 && (res.type === "basic" || res.type === "cors")){
          var salin = res.clone();
          caches.open(VERSI).then(function(c){ c.put(req, salin); });
        }
        return res;
      }).catch(function(){ return hit; });
    })
  );
});
