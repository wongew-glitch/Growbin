package id.rumpun.simulasi;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Rumpun - simulasi marketplace untuk tugas Simulasi Digital Marketing, Universitas Pamulang.
 *
 * Seluruh berkas aplikasi (index.html, ikon, manifest) ikut dikemas di dalam APK pada
 * folder assets. Activity ini menyajikannya lewat alamat maya https://rumpun.local/,
 * bukan lewat file://, supaya penyimpanan peramban dan riwayat navigasi berfungsi
 * seperti di situs sungguhan. Akibatnya aplikasi tetap terbuka penuh tanpa sinyal.
 */
public class MainActivity extends Activity {

    private static final String HOST = "rumpun.local";
    private static final String AWAL = "https://" + HOST + "/index.html";

    private WebView web;

    @Override
    protected void onCreate(Bundle simpanan) {
        super.onCreate(simpanan);

        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings set = web.getSettings();
        set.setJavaScriptEnabled(true);
        set.setDomStorageEnabled(true);
        set.setDatabaseEnabled(true);
        set.setUseWideViewPort(true);
        set.setLoadWithOverviewMode(true);
        set.setBuiltInZoomControls(false);
        set.setDisplayZoomControls(false);
        set.setSupportZoom(false);
        set.setCacheMode(WebSettings.LOAD_DEFAULT);
        set.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView tampilan, WebResourceRequest minta) {
                return sajikan(minta.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView tampilan, WebResourceRequest minta) {
                return keluar(minta.getUrl());
            }

            @Override
            public void onPageFinished(WebView tampilan, String alamat) {
                terapkanTema();
            }
        });

        /* Service worker memakai jalur permintaan sendiri, jadi harus diarahkan
           ke assets yang sama. Dibungkus try agar aman di perangkat yang WebView-nya
           tidak menyediakannya. */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebResourceRequest minta) {
                        return sajikan(minta.getUrl());
                    }
                });
            } catch (Throwable abaikan) {
                // biarkan; aplikasi tetap jalan tanpa service worker
            }
        }

        if (simpanan != null) {
            web.restoreState(simpanan);
        } else {
            web.loadUrl(AWAL);
        }
    }

    /** Ambil berkas dari dalam APK untuk alamat maya rumpun.local. */
    private WebResourceResponse sajikan(Uri alamat) {
        if (alamat == null || !HOST.equals(alamat.getHost())) {
            return null;
        }
        String jalur = alamat.getPath();
        if (jalur == null || jalur.isEmpty() || "/".equals(jalur)) {
            jalur = "/index.html";
        }
        String berkas = jalur.startsWith("/") ? jalur.substring(1) : jalur;
        try {
            InputStream aliran = getAssets().open(berkas);
            WebResourceResponse balasan =
                    new WebResourceResponse(jenis(berkas), "utf-8", aliran);
            Map<String, String> kepala = new HashMap<String, String>();
            kepala.put("Access-Control-Allow-Origin", "*");
            kepala.put("Cache-Control", "no-cache");
            balasan.setResponseHeaders(kepala);
            return balasan;
        } catch (IOException tidakAda) {
            return null;
        }
    }

    private String jenis(String berkas) {
        if (berkas.endsWith(".html")) return "text/html";
        if (berkas.endsWith(".js")) return "application/javascript";
        if (berkas.endsWith(".css")) return "text/css";
        if (berkas.endsWith(".webmanifest") || berkas.endsWith(".json")) return "application/manifest+json";
        if (berkas.endsWith(".png")) return "image/png";
        if (berkas.endsWith(".svg")) return "image/svg+xml";
        if (berkas.endsWith(".woff2")) return "font/woff2";
        if (berkas.endsWith(".woff")) return "font/woff";
        return "application/octet-stream";
    }

    /** Tautan ke luar (WhatsApp, Instagram, situs Canva) dibuka di aplikasi lain. */
    private boolean keluar(Uri alamat) {
        if (alamat == null) return false;
        if (HOST.equals(alamat.getHost())) return false;
        try {
            Intent buka = new Intent(Intent.ACTION_VIEW, alamat);
            buka.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(buka);
        } catch (Exception tidakAdaAplikasi) {
            // tidak ada aplikasi yang bisa membukanya; diamkan saja
        }
        return true;
    }

    /** Teruskan mode gelap perangkat ke halaman, yang sudah punya dua tema. */
    private void terapkanTema() {
        if (web == null) return;
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        String tema = (mode == Configuration.UI_MODE_NIGHT_YES) ? "dark" : "light";
        try {
            web.evaluateJavascript(
                    "document.documentElement.setAttribute('data-theme','" + tema + "');", null);
        } catch (Throwable abaikan) {
        }
    }

    @Override
    public void onConfigurationChanged(Configuration baru) {
        super.onConfigurationChanged(baru);
        terapkanTema();
    }

    @Override
    public boolean onKeyDown(int kode, KeyEvent peristiwa) {
        if (kode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(kode, peristiwa);
    }

    @Override
    protected void onSaveInstanceState(Bundle keluar) {
        super.onSaveInstanceState(keluar);
        if (web != null) web.saveState(keluar);
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }
}
